# Java do Zero ao Júnior

Plataforma pessoal de estudos feita com HTML, CSS e JavaScript puro. Ela funciona sem instalar dependências e foi pensada para uso no celular, inclusive no GitHub Codespaces.

## Executar

No terminal, dentro desta pasta:

```bash
python3 -m http.server 8080
```

Abra a porta 8080 no navegador quando o Codespaces oferecer essa opção.

## Progresso

Aulas concluídas, anotações e respostas são salvas automaticamente no `localStorage`: ficam neste navegador e neste dispositivo. Se você limpar os dados do navegador ou trocar de aparelho, esses dados não acompanham você.

## Arquivos

- `index.html`: estrutura da página.
- `style.css`: aparência responsiva e modo escuro.
- `course-data.js`: módulos e aulas. Para alterar uma aula, edite o texto nesta lista.
- `app.js`: telas, progresso, anotações e atividades.

## Vídeos

Nesta versão os vídeos estão marcados como **pendentes de validação**. Isso é intencional: não foram colocados IDs, URLs ou vídeos fictícios. Após confirmar um vídeo adequado e incorporável, adicione os dados do vídeo no objeto da aula e o iframe no trecho de vídeo de `app.js`.

## Publicação

Para publicar gratuitamente, você pode usar GitHub Pages. No repositório, abra **Settings → Pages**, selecione a branch `main` e a pasta raiz (`/root`), salve e aguarde o endereço ser exibido pelo GitHub.
